Remove-SmbShare -Name "$name" -Force
Remove-Item �path $path